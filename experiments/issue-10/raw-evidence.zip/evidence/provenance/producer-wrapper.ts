import { install } from '/tmp/pst/michael-denyer_pstack-claude/plugins/pstack/pi/index.ts';
import { defaultSettings } from '/tmp/pst/michael-denyer_pstack-claude/plugins/pstack/pi/config.ts';
export default function(pi) {
 pi.registerFlag('pstack-depth', {type:'string',description:'Verification child depth'});
 const settings=defaultSettings(()=>Number(pi.getFlag('pstack-depth'))||0);
 settings.agentDir='/tmp/pgx-issue10-runtime/producer';
 settings.pi={command:'pi',args:['-ne','-ns','-np','--no-mcp']};
 install(pi,settings);
}
