Producer source repository https://github.com/michael-denyer/pstack-claude
Source archive package.json version 0.9.102; current main API SHA observed 356c6e0f978df729eb16f227d795f34d221c5aad. Archive commit identity is not independently guaranteed; file hashes supplied.
Real child verification wrapper overrides only scratch agentDir and child discovery isolation flags. No globally installed package or global configuration changed.
Installed local @casualjim/pi-pstack differs and does not emit pstack-agent; this is source-producer compatibility verification, not proof of identical user installation.
